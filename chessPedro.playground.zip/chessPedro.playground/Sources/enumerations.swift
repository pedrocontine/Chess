import Foundation

// ----------------------------------------------------------------------------------------------------------------
// ENUMERATIONS
// ----------------------------------------------------------------------------------------------------------------

//Pieces colors
public enum Color{
    case black
    case white
}

//Types of moviments
public enum TypeOfMove{
    case horizontal
    case vertical
    case diagonal1
    case diagonal2
    case diagonal3
    case diagonal4
    case knight
    case castling
    case error
}
