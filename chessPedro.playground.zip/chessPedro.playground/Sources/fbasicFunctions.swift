import Foundation

// ----------------------------------------------------------------------------------------------------------------
//  BASIC FUNCTIONS
// ----------------------------------------------------------------------------------------------------------------

//Function to create a filled chessBoard to start a new game
public func createChessBoard() -> [[Piece?]]{
    
    //Matriz to use as board, without pieces by default
    var chessBoard = [[Piece?]](repeating: [Piece?](repeating: nil, count: 8), count: 8)
    
    //Array to storage the pieces
    let arrayPieces = createPieces()
    
    //Fill the chessboard with the pieces in the original position
    chessBoard = putPiecesOnChessboard(emptyChessBoard: chessBoard, arrayPieces: arrayPieces)
    
    return chessBoard
}

//Function that create the pieces and save in an array.
public func createPieces() -> [Piece]{
    
    //b is short for Black, w is short for White.
    let bPaw: Paw = Paw(color: .black, symbol: "♙")
    let bRook: Rook = Rook(color: .black, symbol: "♖", rightMoved: false, leftMoved: false)
    let bKnight: Knight = Knight(color: .black, symbol: "♘")
    let bBishop: Bishop = Bishop(color: .black, symbol: "♗")
    let bQueen: Queen = Queen(color: .black, symbol: "♕")
    let bKing: King = King(color: .black, symbol: "♔", moved: false)
    
    let wPaw: Paw = Paw(color: .white, symbol: "\u{265F}\u{fe0e}")
    let wRook: Rook = Rook(color: .white, symbol: "♜", rightMoved: false, leftMoved: false)
    let wKnight: Knight = Knight(color: .white, symbol: "♞")
    let wBishop: Bishop = Bishop(color: .white, symbol: "♝")
    let wQueen: Queen = Queen(color: .white, symbol: "♛")
    let wKing: King = King(color: .white, symbol: "♚", moved: false)
    
    
    let arrayPieces: [Piece] = [bPaw, bRook, bKnight, bBishop, bQueen, bKing, wPaw, wRook, wKnight, wBishop, wQueen, wKing]
    
    return arrayPieces
}

//Function to put the pieces on the chessboard
public func putPiecesOnChessboard(emptyChessBoard: [[Piece?]], arrayPieces: [Piece]) -> [[Piece?]]{
    
    var filledChessBoard: [[Piece?]] = emptyChessBoard
    let arrayPieces: [Piece] = arrayPieces
    
    for line in 0...7{
        for column in 0...7{
            //Black Pieces
            if line == 0{
                if (column == 0 || column == 7){
                    filledChessBoard[line][column] = arrayPieces[1]
                }
                else if (column == 1 || column == 6){
                    filledChessBoard[line][column] = arrayPieces[2]
                }
                else if (column == 2 || column == 5){
                    filledChessBoard[line][column] = arrayPieces[3]
                }
                else if column == 3{
                    filledChessBoard[line][column] = arrayPieces[4]
                }
                else if column == 4{
                    filledChessBoard[line][column] = arrayPieces[5]
                }
            }
                //Black Paws
            else if line == 1{
                filledChessBoard[line][column] = arrayPieces[0]
            }
                //White Paws
            else if line == 6{
                filledChessBoard[line][column] = arrayPieces[6]
            }
                //White Pieces
            else if line == 7{
                if (column == 0 || column == 7){
                    filledChessBoard[line][column] = arrayPieces[7]
                }
                else if (column == 1 || column == 6){
                    filledChessBoard[line][column] = arrayPieces[8]
                }
                else if (column == 2 || column == 5){
                    filledChessBoard[line][column] = arrayPieces[9]
                }
                else if column == 3{
                    filledChessBoard[line][column] = arrayPieces[10]
                }
                else if column == 4{
                    filledChessBoard[line][column] = arrayPieces[11]
                }
            }
            else{
                filledChessBoard[line][column] = nil
            }
        }
    }
    
    return filledChessBoard
}

//Function that print the chessboard (TO USE ON MAC)
public func printChessBoard(chessBoard: [[Piece?]]){
    
    let chessBoard: [[Piece?]] = chessBoard
    let arrayEmojis: [String] = ["①","②","③","④","⑤","⑥","⑦","⑧"]
    
    //Spaces between the prints
    print("")
    print("")
    print("")
    
    for line in 0...8{
        var printedLine = ""
        print("")
        for column in 0...8{
            if (line != 0 && column != 0){
                if chessBoard[line-1][column-1] == nil{
                    printedLine += ("  ▢ ")
                }
                else{
                    printedLine += "  " + (chessBoard[line-1][column-1]?.symbol)! + " "
                }
            }
            else if (line == 0 && column == 0){
                printedLine += ("    ")
            }
            else if (line == 0){
                printedLine += ("  \(arrayEmojis[column-1]) ")
            }
            else{
                printedLine += (" \(arrayEmojis[8 - line]) ")
            }
        }
        print(printedLine)
    }
}

//Function to change the turn
func changeTurn(game:Chess, valid:Bool){
    //If the move was made, change the turn
    if valid == true{
        switch game.turn{
        case .white:
            game.turn = .black
        case .black:
            game.turn = .white
        }
    }
        //Dont change the turn
    else{
    }
}
