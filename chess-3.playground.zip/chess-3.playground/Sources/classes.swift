import Foundation

// ----------------------------------------------------------------------------------------------------------------
// CLASSES
// ----------------------------------------------------------------------------------------------------------------

//Generic class
open class Piece{
    var color: Color
    var symbol: String
    
    init(color: Color, symbol: String){
        self.color = color
        self.symbol = symbol
    }
    
    func move(game:Chess, from: (x:Int,y:Int), to: (x:Int,y:Int)) -> (valid:Bool,type:TypeOfMove){
        var moveReturn: (valid:Bool, type:TypeOfMove)
        print("Move")
        moveReturn = (false, .error)
        return moveReturn
    }
}

//Classes of diferent types of pieces
open class Pawn: Piece{
    
    override func move(game:Chess, from: (x:Int,y:Int), to: (x:Int,y:Int)) -> (valid:Bool,type:TypeOfMove){
        
        var moveReturn: (valid:Bool, type:TypeOfMove)
        moveReturn.type = typeOfMove(game: game, fromX: from.x, fromY: from.y, toX: to.x, toY: to.y)
        
        //Verify if is only one square you are trying to move
        if abs(from.y - to.y) == 1{
            //Verify if the move match the color rule
            if isPawnMoveAllowedByColor(game: game, fromY:from.y, toY:to.y){
                //Verify if the move is allowed
                if isPawnMoveValid(game: game, pieceColor: game.turn, moveType: moveReturn.type, toX:to.x, toY:to.y){
                    moveReturn.valid = true
                }
                    //Move invalid
                else{
                    moveReturn.valid = false
                }
            }
                //This pawn color cant move this way
            else{
                moveReturn.valid = false
            }
        }
            //If is the first move, paw can move 2 squares
        else if abs(from.y - to.y) == 2 && isPawnFirstMove(game: game, fromY:from.y, toY:to.y){
            moveReturn.valid = true
        }
            //Invalid move
        else{
            moveReturn.valid = false
        }
        
        return moveReturn
    }
}

open class Rook: Piece{
    
    //Property to verify if the rock move is possible
    var rightMoved:Bool
    var leftMoved:Bool
    
    init(color:Color, symbol:String, rightMoved:Bool, leftMoved:Bool){
        self.rightMoved = rightMoved
        self.leftMoved = leftMoved
        super.init(color:color, symbol:symbol)
    }
    
    override func move(game:Chess, from: (x:Int,y:Int), to: (x:Int,y:Int)) -> (valid:Bool,type:TypeOfMove){
        
        var moveReturn: (valid:Bool, type:TypeOfMove)
        moveReturn.type = typeOfMove(game: game, fromX: from.x, fromY: from.y, toX: to.x, toY: to.y)
        
        //Verify what types of moves are valid
        switch moveReturn.type{
        case .horizontal, .vertical:
            moveReturn.valid = true
        default:
            moveReturn.valid = false
        }
        
        return moveReturn
    }
}

open class Knight: Piece{
    
    override func move(game:Chess, from: (x:Int,y:Int), to: (x:Int,y:Int)) -> (valid:Bool,type:TypeOfMove){
        
        var moveReturn: (valid:Bool, type:TypeOfMove)
        moveReturn.type = typeOfMove(game: game, fromX: from.x, fromY: from.y, toX: to.x, toY: to.y)
        
        //Verify what types of moves are valid
        switch moveReturn.type{
        case .knight:
            moveReturn.valid = true
        default:
            moveReturn.valid = false
        }
        
        return moveReturn
    }
}

open class Bishop: Piece{
    
    override func move(game:Chess, from: (x:Int,y:Int), to: (x:Int,y:Int)) -> (valid:Bool,type:TypeOfMove){
        
        var moveReturn: (valid:Bool, type:TypeOfMove)
        moveReturn.type = typeOfMove(game: game, fromX: from.x, fromY: from.y, toX: to.x, toY: to.y)
        
        //Verify what types of moves are valid
        switch moveReturn.type{
        case .diagonal1, .diagonal2, .diagonal3, .diagonal4 :
            moveReturn.valid = true
        default:
            moveReturn.valid = false
        }
        
        return moveReturn
    }
}

open class Queen: Piece{
    
    override func move(game:Chess, from: (x:Int,y:Int), to: (x:Int,y:Int)) -> (valid:Bool,type:TypeOfMove){
        
        var moveReturn: (valid:Bool, type:TypeOfMove)
        moveReturn.type = typeOfMove(game: game, fromX: from.x, fromY: from.y, toX: to.x, toY: to.y)
        
        //Verify what types of moves are valid
        switch moveReturn.type{
        case .horizontal, .vertical, .diagonal1, .diagonal2, .diagonal3, .diagonal4 :
            moveReturn.valid = true
        default:
            moveReturn.valid = false
        }
        
        return moveReturn
    }
}

open class King: Piece{
    
    //Property to verify if the rock move is possible
    var moved:Bool
    
    init(color:Color, symbol:String, moved:Bool){
        self.moved = moved
        super.init(color:color, symbol:symbol)
    }
    
    override func move(game:Chess, from: (x:Int,y:Int), to: (x:Int,y:Int)) -> (valid:Bool,type:TypeOfMove){
        
        var moveReturn: (valid:Bool, type:TypeOfMove)
        moveReturn.type = typeOfMove(game: game, fromX: from.x, fromY: from.y, toX: to.x, toY: to.y)
        
        //Verify if is only one square you are trying to move
        if abs(from.x - to.x) == 1 || abs(from.y - to.y) == 1{
            //Verify what types of moves are valid
            switch moveReturn.type{
            case .horizontal, .vertical, .diagonal1, .diagonal2, .diagonal3, .diagonal4 :
                moveReturn.valid = true
            default:
                moveReturn.valid = false
            }
        }
            //Verify if is a castling type move
        else if moveReturn.type == .castling{
            //Verify if is the first move of the king and the selected rook
            if isCastlingValid(game: game, fromX:from.x, fromY:from.y, toX:to.x, toY:to.y){
                moveReturn.valid = true
            }
                //Cant to the castling
            else{
                moveReturn.valid = false
            }
        }
        else{
            moveReturn.valid = false
        }
        
        return moveReturn
    }
}

//Class to start a new game and to use the functions to play
open class Chess{
    var turn: Color
    var chessBoard: [[Piece?]]
    var endGame: Bool
    
    //Set the initial parameters
    public init(){
        self.turn = .white
        self.chessBoard = createChessBoard()
        self.endGame = false
    }
    
    //Call the function to print the board
    public func printBoard(game:Chess){
        // printChessBoard(chessBoard: game.chessBoard)
        printChessBoard(chessBoard: game.chessBoard)
    }
    
    //Call the function to move a piece
    public func move(game:Chess, from: (x:Int,y:Int), to: (x:Int,y:Int)) -> Bool{
        
        //Variable to catch the return bool
        var valid = false
        
        //Verify if the coordinates are valid
        guard areCoordinatesInChessboard(from: (x: from.x, y: from.y), to: (x: to.x, y: to.y)) else { return false }
        
        //Convert the coordinates given to matrix axes
        let coordinates = convertCoordinates(from: (x: from.x, y: from.y), to: (x: to.x, y: to.y))
        
        //Verify if in the origin has a piece
        if let piece = game.chessBoard[coordinates.fromY][coordinates.fromX]{
            
            //Verify if the color of the piece selected is the color of the turn
            if piece.color == game.turn{
                
                //Call the especific piece move function
                let moveResult = piece.move(game: game, from: (x:coordinates.fromX, y:coordinates.fromY), to: (x:coordinates.toX, y:coordinates.toY))
                
                //Make all the verifications if the move is possible
                if isMovePossible(game: game, piece:piece, moveResult: moveResult, coordinates:coordinates) == true{
                    valid = true
                }
                    //The selected piece cant move this way
                else{
                    valid = false
                }
            }
                //Isnt your turn to play
            else{
                valid = false
            }
        }
            //If there isnt a piece to move
        else{
            valid = false
        }
        
        //If the move was made, change the turn
        changeTurn(game: game, valid:valid)
        
        return valid
    }
}
