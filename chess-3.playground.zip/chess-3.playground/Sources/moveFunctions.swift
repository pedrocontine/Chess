import Foundation

// ----------------------------------------------------------------------------------------------------------------
//  MOVEMENT FUNCTIONS
// ----------------------------------------------------------------------------------------------------------------

//Function to validate if the coordinates given are in the chessboard
public func areCoordinatesInChessboard(from: (x:Int,y:Int), to: (x:Int,y:Int)) -> Bool{
    
    //Check board limits
    guard case 1...8 = from.x,
        case 1...8 = from.y,
        case 1...8 = to.x,
        case 1...8 = to.y
        else {
            // out of range
            return false
    }
    return true
}

//Function that convert the coordinates typed to the matriz scale
public func convertCoordinates(from: (x:Int,y:Int), to: (x:Int,y:Int)) -> (fromX:Int, fromY:Int, toX:Int, toY:Int){
    
    //Create a tuple
    var coordinates: (fromX:Int, fromY:Int, toX:Int, toY:Int)
    
    //Make the conversions
    coordinates.fromY = 8 - from.y
    coordinates.fromX = from.x - 1
    coordinates.toY = 8 - to.y
    coordinates.toX = to.x - 1
    
    return coordinates
}

//Function that return the type of moviment you are trying to do
public func typeOfMove(game:Chess, fromX:Int, fromY:Int, toX:Int, toY:Int) -> TypeOfMove{
    var typeOfMove:TypeOfMove
    
    //Verify if the move is in "L" format (Knight)
    if isKnightMove(fromX: fromX, fromY: fromY, toX: toX, toY: toY){
        typeOfMove = .knight
    }
        //Verify if the moviment is castling
    else if isCastling(game: game, fromX: fromX, fromY: fromY, toX: toX, toY: toY){
        typeOfMove = .castling
    }
        //Verify if the moviment is horizontal
    else if isHorizontalMove(fromX: fromX, fromY: fromY, toX: toX, toY: toY){
        typeOfMove = .horizontal
    }
        //Verify if the moviment is vertical
    else if isVerticalMove(fromX: fromX, fromY: fromY, toX: toX, toY: toY){
        typeOfMove = .vertical
    }
        //Verify if the moviment is diagonal1 (up and right)
    else if isDiagonal1Move(fromX: fromX, fromY: fromY, toX: toX, toY: toY){
        typeOfMove = .diagonal1
    }
        //Verify if the moviment is diagonal2 (up and left)
    else if isDiagonal2Move(fromX: fromX, fromY: fromY, toX: toX, toY: toY){
        typeOfMove = .diagonal2
    }
        //Verify if the moviment is diagonal3 (down and left)
    else if isDiagonal3Move(fromX: fromX, fromY: fromY, toX: toX, toY: toY){
        typeOfMove = .diagonal3
    }
        //Verify if the moviment is diagonal4 (down and right)
    else if isDiagonal4Move(fromX: fromX, fromY: fromY, toX: toX, toY: toY){
        typeOfMove = .diagonal4
    }
    else{
        typeOfMove = .error
    }
    
    return typeOfMove
}

//Function to verify if the movimnent is in "L" format
public func isKnightMove(fromX:Int, fromY:Int, toX:Int, toY:Int) -> Bool{
    //If you move two columns and one line, the moviment is in L shape
    if abs(fromX - toX) == 2 && abs(fromY - toY) == 1{
        return true
    }
        //If you move one column and two lines, the moviment is in L shape
    else if abs(fromX - toX) == 1 && abs(fromY - toY) == 2{
        return true
    }
        //Is not a valid knight move
    else{
        return false
    }
}

//Function to verify if the moviment is horizontal
public func isHorizontalMove(fromX:Int, fromY:Int, toX:Int, toY:Int) -> Bool{
    //If the original line is the same as the final line, but the column changed, the moviment is horizontal
    if (abs(fromY - toY) == 0 && abs(fromX - toX) != 0){
        return true
    }
        //Isnt horizontal
    else{
        return false
    }
}

//Function to verify if the moviment is horizontal
public func isVerticalMove(fromX:Int, fromY:Int, toX:Int, toY:Int) -> Bool{
    //If the original column is the same as the final column, but the line changed, the moviment is horizontal
    if (abs(fromX - toX) == 0 && abs(fromY - toY) != 0){
        return true
    }
        //Isnt horizontal
    else{
        return false
    }
}

//Function to verify if the moviment is diagonal1
public func isDiagonal1Move(fromX:Int, fromY:Int, toX:Int, toY:Int) -> Bool{
    //If the piece went right and up, is diagonal 1
    if isRight(fromX: fromX, toX: toX) && isUp(fromY: fromY, toY: toY){
        return true
    }
        //Isnt diagonal1
    else{
        return false
    }
}

//Function to verify if the moviment is diagonal2
public func isDiagonal2Move(fromX:Int, fromY:Int, toX:Int, toY:Int) -> Bool{
    //If the piece went left and up, is diagonal 2
    if isLeft(fromX: fromX, toX: toX) && isUp(fromY: fromY, toY: toY){
        return true
    }
        //Isnt diagonal2
    else{
        return false
    }
}

//Function to verify if the moviment is diagonal3
public func isDiagonal3Move(fromX:Int, fromY:Int, toX:Int, toY:Int) -> Bool{
    //If the piece went left and down, is diagonal 3
    if isLeft(fromX: fromX, toX: toX) && isDown(fromY: fromY, toY: toY){
        return true
    }
        //Isnt diagonal3
    else{
        return false
    }
}

//Function to verify if the moviment is diagonal4
public func isDiagonal4Move(fromX:Int, fromY:Int, toX:Int, toY:Int) -> Bool{
    //If the piece went right and down, is diagonal 4
    if isRight(fromX: fromX, toX: toX) && isDown(fromY: fromY, toY: toY){
        return true
    }
        //Isnt diagonal4
    else{
        return false
    }
}

//Function to verify if the moviment is a castling
public func isCastling(game:Chess, fromX:Int, fromY:Int, toX:Int, toY:Int) -> Bool{
    
    //If there is a king in the origin
    if let originPiece = game.chessBoard[fromY][fromX] as? King {
        //If there is a rook in the destiny
        if let destinyPiece = game.chessBoard[toY][toX] as? Rook {
            //If they are the same color
            if originPiece.color == destinyPiece.color{
                return true
            }
                //They arent
            else{
                return false
            }
        }
            //Isnt a rook
        else{
            return false
        }
    }
        //Isnt a king
    else {
        return false
    }
}

//Function to verify if the moviment is to the right
public func isRight(fromX:Int, toX:Int) -> Bool{
    if toX > fromX{
        return true
    }
    else{
        return false
    }
}

//Function to verify if the moviment is to the left
public func isLeft(fromX:Int, toX:Int) -> Bool{
    if toX < fromX{
        return true
    }
    else{
        return false
    }
}

//Function to verify if the moviment is up
public func isUp(fromY:Int, toY:Int) -> Bool{
    if toY < fromY{
        return true
    }
    else{
        return false
    }
}

//Function to verify if the moviment is down
public func isDown(fromY:Int, toY:Int) -> Bool{
    if toY > fromY{
        return true
    }
    else{
        return false
    }
}

//Function to verify if its the pawn first move
public func isPawnFirstMove(game:Chess, fromY:Int, toY:Int) -> Bool{
    var valid:Bool = false
    //Verify if is in inicial position
    switch game.turn{
    case .white:
        if (fromY == 6 && toY == 4){
            valid = true
        }
            //Isnt in inicial position, cant move
        else{
            valid = false
        }
    case .black:
        if (fromY == 1 && toY == 3){
            valid = true
        }
            //Isnt in inicial position, cant move
        else{
            valid = false
        }
    }
    return valid
}

//Function to verify if the pawn move match with the pawn color
public func isPawnMoveAllowedByColor(game:Chess, fromY:Int, toY:Int) -> Bool{
    
    var valid:Bool = false
    
    //Verify if is white and move up
    if (game.turn == .white && isUp(fromY: fromY, toY: toY)) {
        valid = true
    }
        //Verify if is black and move down
    else if (game.turn == .black && isDown(fromY: fromY, toY: toY)){
        valid = true
    }
        //Invalid move
    else{
        valid = false
    }
    
    return valid
}

//Function to verify if the pawn move is valid
public func isPawnMoveValid(game:Chess, pieceColor:Color, moveType: TypeOfMove, toX:Int, toY:Int) -> Bool{
    
    var valid:Bool = false
    
    //Verify if is a vertical move, only valid if destiny is empty
    if moveType == .vertical && isDestinyEmpty(game:game, toX:toX, toY:toY){
        valid = true
    }
        //If its a diagonal move, allowed only if it has an enemy piece
    else{
        switch moveType{
        case .diagonal1, .diagonal2, .diagonal3, .diagonal4 :
            //If its empty, cant move
            if isDestinyEmpty(game:game, toX:toX, toY:toY){
                valid = false
            }
                //Isnt empty
            else{
                //Verify if is an enemy
                if isPieceEnemy(game:game, pieceColor:pieceColor, toX:toX, toY:toY){
                    valid = true
                }
                    //Isnt enemy, cant move
                else{
                    valid = false
                }
            }
        default:
            valid = false
        }
    }
    
    return valid
}

//Function to verify if the castling move is valid
public func isCastlingValid(game:Chess, fromX:Int, fromY:Int, toX:Int, toY:Int) -> Bool{
    //If its a king selected
    if let king = game.chessBoard[fromY][fromX] as? King {
        //If its a rook selected
        if let rook = game.chessBoard[toY][toX] as? Rook {
            //If its the king first move
            if king.moved == false{
                //If its the left rook first move
                if toX == 0 && rook.leftMoved == false{
                    return true
                }
                    //If its the right rook first move
                else if toX == 7 && rook.rightMoved == false{
                    return true
                }
                    //Isnt the first move, cant castling
                else{
                    return false
                }
            }
                //Isnt
            else{
                return false
            }
        }
            //Isnt a rook
        else{
            return false
        }
    }
        //Isnt a king
    else{
        return false
    }
}

//Function to verify if the destiny is empty
public func isDestinyEmpty(game:Chess, toX:Int, toY:Int) -> Bool{
    if game.chessBoard[toY][toX] == nil{
        return true
    }
        //Isnt empty
    else{
        return false
    }
}

//Function to verify if the piece in the destiny is an enemy
public func isPieceEnemy(game:Chess, pieceColor:Color, toX:Int, toY:Int) -> Bool{
    //If their colors are diferent, they are enemys
    if pieceColor != game.chessBoard[toY][toX]?.color{
        return true
    }
        //Isnt empty
    else{
        return false
    }
}

//Function to move the piece to the destination
public func movePiece(game:Chess, moveType: TypeOfMove, fromX:Int, fromY:Int, toX:Int, toY:Int){
    
    //Update the moved status if it was a rook
    if let piece = game.chessBoard[fromY][fromX] as? Rook{
        //If it was the right rook that moved
        if fromX == 7{
            piece.rightMoved = true
        }
            //If it was the left rook that moved
        else if fromX == 0{
            piece.leftMoved = true
        }
        else{
        }
    }
        //It wasnt a rook that moved
    else {
    }
    
    //Update the moved status if it was a king
    if let piece = game.chessBoard[fromY][fromX] as? King{
        piece.moved = true
    }
        //It wasnt a king that moved
    else {
    }
    
    //If the move is castling type
    if moveType == .castling{
        //Verify if is castling right
        if isRight(fromX: fromX, toX: toX){
            //Move the king two squares right
            game.chessBoard[fromY][fromX+2] = game.chessBoard[fromY][fromX]
            //Move the rook to the left square of the king
            game.chessBoard[fromY][fromX+1] = game.chessBoard[toY][toX]
            //Clean the original king position
            game.chessBoard[fromY][fromX] = nil
            //Clean the original rook position
            game.chessBoard[toY][toX] = nil
        }
            //Its castling left
        else{
            //Move the king two squares left
            game.chessBoard[fromY][fromX-2] = game.chessBoard[fromY][fromX]
            //Move the rook to the right square of the king
            game.chessBoard[fromY][fromX-1] = game.chessBoard[toY][toX]
            //Clean the original king position
            game.chessBoard[fromY][fromX] = nil
            //Clean the original rook position
            game.chessBoard[toY][toX] = nil
        }
    }
        //Other moves, just change the pieces
    else{
        //Move the selected piece from the origin to the destiny
        game.chessBoard[toY][toX] = game.chessBoard[fromY][fromX]
        //Clean the original position
        game.chessBoard[fromY][fromX] = nil
    }
    
    //Update the chessboard print
    game.printBoard(game: game)
}

//Function to verify if there are pieces between the origin and the destiny
public func isPathFree(game:Chess, moveType:TypeOfMove, fromX:Int, fromY:Int, toX:Int, toY:Int, isForCheck:Bool) -> (isFree:Bool, posX:Int, posY:Int){
    
    
    var result:(isFree:Bool, posX:Int, posY:Int)
    result = (isFree: true, posX:0, posY:0)
    var squares:Int
    
    //Calculate hom many squares there are between the origin and the destiny
    squares = howManySquares(moveType:moveType, fromX:fromX, fromY:fromY, toX:toX, toY:toY)
    
    //If the isPathFree function will be used in normal moves, make squares -1. If is for check, keep the square.
    if isForCheck == false{
        squares -= 1
    }
    
    //If its only one square to move, the path is already free
    if (squares == 1 && isForCheck == false){
       result.isFree = true
    }
    //If its more than one, verify if the path is free
    else if squares >= 1{
        for i in 1...(squares){
            if result.isFree == false{
                break
            }
            else if (moveType == .horizontal || moveType == .castling){
                if isRight(fromX: fromX, toX: toX){
                    if game.chessBoard[fromY][fromX+i] != nil{
                        result.posX = (fromX+i)
                        result.posY = (fromY)
                        result.isFree = false
                    }
                }
                if isLeft(fromX: fromX, toX: toX){
                    if game.chessBoard[fromY][fromX-i] != nil{
                        result.posX = (fromX-i)
                        result.posY = (fromY)
                        result.isFree = false
                    }
                }
            }
            else if moveType == .vertical{
                if isUp(fromY: fromY, toY: toY){
                    if game.chessBoard[fromY-i][fromX] != nil{
                        result.posX = (fromX)
                        result.posY = (fromY-i)
                        result.isFree = false
                    }
                }
                if isDown(fromY: fromY, toY: toY){
                    if game.chessBoard[fromY+i][fromX] != nil{
                        result.posX = (fromX)
                        result.posY = (fromY+i)
                        result.isFree = false
                        
                    }
                }
            }
            else if moveType == .diagonal1{
                if game.chessBoard[fromY-i][fromX+i] != nil{
                    result.posX = (fromX+i)
                    result.posY = (fromY-i)
                    result.isFree = false
                }
            }
            else if moveType == .diagonal2{
                if game.chessBoard[fromY-i][fromX-i] != nil{
                    result.posX = (fromX-i)
                    result.posY = (fromY-i)
                    result.isFree = false
                }
            }
            else if moveType == .diagonal3{
                if game.chessBoard[fromY+i][fromX-i] != nil{
                    result.posX = (fromX-i)
                    result.posY = (fromY+i)
                    result.isFree = false
                }
            }
            else if moveType == .diagonal4{
                if game.chessBoard[fromY+i][fromX+i] != nil{
                    result.posX = (fromX+i)
                    result.posY = (fromY+i)
                    result.isFree = false
                }
            }
        }
    }
    return result
}

//Function that unit all the other functions that verify if move is possible
public func isMovePossible(game:Chess, piece:Piece, moveResult:(valid:Bool, type: TypeOfMove), coordinates:(fromX:Int, fromY:Int, toX:Int, toY:Int)) -> Bool{
    
    var valid:Bool = false
    
    //If the moviment is valid
    if moveResult.valid{
        //Verify if there are pieces on the way
        if isPathFree(game:game, moveType: moveResult.type, fromX:coordinates.fromX, fromY:coordinates.fromY, toX:coordinates.toX, toY:coordinates.toY, isForCheck: false).isFree{
            
            //Verify if the destiny is empty
            if isDestinyEmpty(game:game, toX: coordinates.toX, toY: coordinates.toY){
                //Move, just changing position
                movePiece(game:game, moveType: moveResult.type, fromX: coordinates.fromX, fromY: coordinates.fromY, toX: coordinates.toX, toY: coordinates.toY)
                valid = true
            }
                //Isnt empty
            else{
                //Verify if the piece is an enemy
                if isPieceEnemy(game:game, pieceColor: piece.color, toX: coordinates.toX, toY: coordinates.toY){
                    //Move, capturing the enemy piece
                    movePiece(game:game, moveType: moveResult.type, fromX: coordinates.fromX, fromY: coordinates.fromY, toX: coordinates.toX, toY: coordinates.toY)
                    valid = true
                }
                    //Its an ally piece
                else{
                    //If the move is a castling
                    if moveResult.type == .castling{
                        movePiece(game:game, moveType: moveResult.type, fromX: coordinates.fromX, fromY: coordinates.fromY, toX: coordinates.toX, toY: coordinates.toY)
                        valid = true
                    }
                        //Isnt a castling, cant move
                    else{
                        valid = false
                    }
                }
            }
        }
            //Path isnt free, cant move
        else{
            valid = false
        }
    }
    return valid
}

//Function to calculate how far a piece is from a given x and y depending of the move type
public func howManySquares(moveType:TypeOfMove, fromX:Int, fromY:Int, toX:Int, toY:Int) -> Int{
    
    var squares:Int
    
    switch moveType{
    case .horizontal, .castling:
        squares = abs(fromX - toX)
    case .vertical, .diagonal1, .diagonal2, .diagonal3, .diagonal4:
        squares = abs(fromY - toY)
    default:
        squares = 2
    }
    
    return squares
    
}

//Function to catch the piece type
public func catchPieceType(game:Chess, posX:Int, posY:Int) -> TypeOfPiece{
    
    var pieceType:TypeOfPiece
    
    if let piece = game.chessBoard[posY][posX] as? Pawn {
        pieceType = .pawn
    }
    else if let piece = game.chessBoard[posY][posX] as? Rook{
        pieceType = .rook
    }
    else if let piece = game.chessBoard[posY][posX] as? Knight{
        pieceType = .knight
    }
    else if let piece = game.chessBoard[posY][posX] as? Bishop{
        pieceType = .bishop
    }
    else if let piece = game.chessBoard[posY][posX] as? Queen{
        pieceType = .queen
    }
    else if let piece = game.chessBoard[posY][posX] as? King{
        pieceType = .king
    }
    else{
        pieceType = .error
    }
    
    return pieceType
}

//Function that return the farthest point(x,y) on the chessboard given a origin x,y
public func farthestPoint(fromX:Int, fromY:Int) -> (posX:[Int], posY:[Int]){
    
    //Arrays to storage the points
    var arrayPosX:[Int] = [7, 0, fromX, fromX, fromX, fromX, fromX, fromX]
    var arrayPosY:[Int] = [fromY, fromY, 0, 7, fromY, fromY, fromY, fromY]
    
    //Horizontal right farthest point (fromY,7)
    //Horizontal left farthest point (fromY, 0)
    //vertical up farthest point (0, fromX)
    //vertical down farthest point (7, fromX)
    
    for i in 4...7{
        switch i{
        case 4:
            while (arrayPosX[i] < 7 && arrayPosY[i] > 0){
                arrayPosY[i] -= 1
                arrayPosX[i] += 1
            }
        case 5:
            while (arrayPosX[i] > 0 && arrayPosY[i] > 0){
                arrayPosY[i] -= 1
                arrayPosX[i] -= 1
            }
        case 6:
            while (arrayPosX[i] > 0 && arrayPosY[i] < 7){
                arrayPosY[i] += 1
                arrayPosX[i] -= 1
            }
        case 7:
            while (arrayPosX[i] < 7 && arrayPosY[i] < 7){
                arrayPosY[i] += 1
                arrayPosX[i] += 1
            }
        default:
            print("This should never be printed.")
        }
    }
    return (arrayPosX, arrayPosY)
}


//Function to verify if the king is in check
public func isKingInCheck(game:Chess, fromX:Int, fromY:Int, color:Color) -> Bool{
    
    var valid:Bool = false
    var squares:Int
    //Array of all types of move
    var moveTypes:[TypeOfMove] = [.horizontal, .horizontal, .vertical, .vertical, .diagonal1, .diagonal2, .diagonal3, .diagonal4]
    //Arrays the storage all the farthests points from the king
    let points = farthestPoint(fromX: fromX, fromY: fromY)
    
    print(points.posX)
    print(points.posY)
    
    //For that verify in all types of moves if there is some piece in the way
    for column in 0...7{
        
        //Analize the path of all move types to see if they are empty
        let pathAnalizeResult = isPathFree(game:game, moveType: moveTypes[column], fromX:fromX, fromY:fromY, toX: points.posX[column], toY: points.posY[column], isForCheck: true)
        let pieceType = catchPieceType(game: game, posX: pathAnalizeResult.posX, posY: pathAnalizeResult.posY)
        
        print(moveTypes[column])
        print(pathAnalizeResult)
        
        //If path isnt free
        if pathAnalizeResult.isFree != true{
            //There is a piece in the way, lets verify if its an enemy piece
            if isPieceEnemy(game: game, pieceColor: color, toX: pathAnalizeResult.posX, toY: pathAnalizeResult.posY){
                
                //Its enemy, lets see how far it is from our king
                squares = howManySquares(moveType: moveTypes[column], fromX:fromX, fromY:fromY, toX:pathAnalizeResult.posX, toY:pathAnalizeResult.posY)
                
                //If its only one square far, lets list what types of pieces could harm the king
                if squares == 1{
                    switch moveTypes[column]{
                    case .horizontal, .vertical:
                        if (pieceType == .rook || pieceType == .queen){
                            //Its a piece that can harm the king, so he is in check
                            valid = true
                            break
                        }
                    case .diagonal1, .diagonal2, .diagonal3, .diagonal4:
                        if (pieceType == .pawn || pieceType == .bishop || pieceType == .queen){
                            //Its a piece that can harm the king, so he is in check
                            valid = true
                            break
                        }
                    default:
                        valid = false
                    }
                }
                //Its more than one square far
                else{
                    switch moveTypes[column]{
                    case .horizontal, .vertical:
                        if (pieceType == .rook || pieceType == .queen){
                            //Its a piece that can harm the king, so he is in check
                            valid = true
                            break
                        }
                    case .diagonal1, .diagonal2, .diagonal3, .diagonal4:
                        if (pieceType == .bishop || pieceType == .queen){
                            //Its a piece that can harm the king, so he is in check
                            valid = true
                            break
                        }
                    default:
                        valid = false
                    }
                }
            }
        }
    }
    
    return valid
    
}
