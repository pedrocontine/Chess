import Foundation


// ----------------------------------------------------------------------------------------------------------------
// TESTS
// ----------------------------------------------------------------------------------------------------------------

//Start a new game
var game = Chess()

game.printBoard(game: game)


game.move(game: game, from: (x:1,y:2), to: (x:1,y:4))
game.move(game: game, from: (x:1,y:7), to: (x:1,y:5))
game.move(game: game, from: (x:2,y:1), to: (x:3,y:3))
game.move(game: game, from: (x:1,y:8), to: (x:1,y:6))
game.move(game: game, from: (x:2,y:2), to: (x:2,y:3))
game.move(game: game, from: (x:2,y:8), to: (x:3,y:6))
game.move(game: game, from: (x:3,y:1), to: (x:1,y:3))
game.move(game: game, from: (x:3,y:6), to: (x:5,y:5))
game.move(game: game, from: (x:4,y:1), to: (x:2,y:1))
game.move(game: game, from: (x:5,y:5), to: (x:6,y:3))
game.move(game: game, from: (x:2,y:1), to: (x:1,y:2))
game.move(game: game, from: (x:1,y:6), to: (x:8,y:6))
game.move(game: game, from: (x:5,y:1), to: (x:1,y:1))
game.move(game: game, from: (x:5,y:7), to: (x:5,y:5))
game.move(game: game, from: (x:4,y:2), to: (x:4,y:3))
game.move(game: game, from: (x:4,y:8), to: (x:7,y:5))
game.move(game: game, from: (x:3,y:1), to: (x:4,y:2))

isKingInCheck(game:game, fromX:3, fromY:6, color: .white)
// return color == .black ? "b" : "w"

//Arquitetura de solucoes
